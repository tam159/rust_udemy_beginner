#[allow(unused_variables)]
#[allow(unused_assignments)]

fn main() {
    let pi: f32 = 4.0;
    let million = 1_000_000;
    println!("{}", million);
    let is_day = true;
    let is_night = false;
    println!("{}", is_day);
    let char1 = 'A';
    let char1 = '\u{1F601}';
    println!("{}", char1);
}
