#[allow(unused_variables)]
#[allow(unused_assignments)]

fn main() {
    let name = "Alex";
    let mut age = 32;

    let amount: i64 = 9387592743847;
    println!("{}", age);

    age = 43;

    println!("{}", age);

    let color = "blue";
    let color = 86;

    println!("{}", color);

    let (a, b, c) = (43, 85, "red");
}
